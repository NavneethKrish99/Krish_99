function x=fulladder(x,y,z)
a=Xor(x,y);
sum=Xor(a,z)
b=And(x,y);
c=And(y,z);
d=And(x,z);
e=o_r(b,c);
carry=o_r(e,d)
end


