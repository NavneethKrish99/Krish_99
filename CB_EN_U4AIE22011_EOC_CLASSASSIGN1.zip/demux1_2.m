function x=demux1_2(sel,in)

if sel==0&&in==0
    d0=0
    d1=0
elseif sel==0&&in==1
    d0=1
    d1=0
elseif sel==1&&in==0
    d0=0
    d1=0
elseif sel==1&&in==1
    d0=0
    d1=1
else

    disp("enter in binary form")
    
end
end
