function x=halfadder(x,y)
sum=Xor(x,y)
carry=And(x,y)

end
