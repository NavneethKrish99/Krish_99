function x=demux1_8(sel2,sel1,sel0,inp)
if sel2==0&&sel1==0&&sel0==0
    d0=inp
    d1=0
    d2=0
    d3=0
    d4=0
    d5=0
    d6=0
    d7=0
elseif sel2==0&&sel1==0&&sel0==1
    d0=0
    d1=inp
    d2=0
    d3=0
    d4=0
    d5=0
    d6=0
    d7=0
    
elseif sel2==0&&sel1==1&&sel0==0
    d0=0
    d1=0
    d2=inp
    d3=0
    d4=0
    d5=0
    d6=0
    d7=0
    
elseif sel2==0&&sel1==1&&sel0==1
    d0=0
    d1=0
    d2=0
    d3=inp
    d4=0
    d5=0
    d6=0
    d7=0
    elseif sel2==1&&sel1==0&&sel0==0
    d0=0
    d1=0
    d2=0
    d3=0
    d4=inp
    d5=0
    d6=0
    d7=0
    elseif sel2==1&&sel1==0&&sel0==1
    d0=0
    d1=0
    d2=0
    d3=0
    d4=0
    d5=inp
    d6=0
    d7=0
    elseif sel2==1&&sel1==1&&sel0==0
    d0=0
    d1=0
    d2=0
    d3=0
    d4=0
    d5=0
    d6=inp
    d7=0
    elseif sel2==1&&sel1==1&&sel0==1
    d0=0
    d1=0
    d2=0
    d3=0
    d4=0
    d5=0
    d6=0
    d7=inp

else 
    disp("enter in binary")

end