function x=mux8_1(s2,s1,s0,d0,d1,d2,d3,d4,d5,d6,d7)
if s2==0&&s1==0&&s0==0
    out=d0
elseif s2==0&&s1==0&&s0==1
    out=d1
elseif s2==0&&s1==1&&s0==0
    out=d2
elseif s2==0&&s1==1&&s0==1
    out=d3
elseif s2==1&&s1==0&&s0==0
    out=d4
elseif s2==1&&s1==0&&s0==1
    out=d5
elseif s2==1&&s1==1&&s0==0
    out=d6
elseif s2==1&&s1==1&&s0==1
    out=d7
else
    disp("enter in binary form")
    
end
end

