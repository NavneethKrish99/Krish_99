function x=mux2_1(s0,D1,D0)
if s0==0          
    out=D0
elseif s0==1
    out=D1
else
    disp("enter the value in binary form");
end
end

    