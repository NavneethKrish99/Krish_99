function x=mux4_1(s1,s0,d0,d1,d2,d3)
if s1==0&&s0==0
    out=d0
elseif s1==0&&s0==1
    out=d1
elseif s1==1&&s0==0
    out=d2
elseif s1==1&&s0==1
    out=d3
else
    disp("enter in binary form")
    

end
end

