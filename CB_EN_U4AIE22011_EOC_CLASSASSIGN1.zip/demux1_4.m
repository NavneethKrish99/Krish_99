function x=demux1_4(sel1,sel0,inp)
if sel1==0&&sel0==0
    d0=inp
    d1=0
    d2=0
    d3=0
elseif sel1==0&&sel0==1
    d0=0
    d1=inp
    d2=0
    d3=0
    
elseif sel1==1&&sel0==0
    d0=0
    d1=0
    d2=inp
    d3=0
    
elseif sel1==1&&sel0==1
    d0=0
    d1=0
    d2=0
    d3=inp
else
    disp("enter in binary form")
    
end
end